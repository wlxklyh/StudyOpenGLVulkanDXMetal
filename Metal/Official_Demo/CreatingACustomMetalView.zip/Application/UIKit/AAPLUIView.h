/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Customized view for iOS & tvOS
*/

#import <Metal/Metal.h>
#import <UIKit/UIKit.h>
#import "AAPLView.h"

@interface AAPLUIView : AAPLView

@end
