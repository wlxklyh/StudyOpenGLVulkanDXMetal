/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Header for our iOS & tvOS application delegate
*/

#import <UIKit/UIKit.h>

@interface AAPLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
