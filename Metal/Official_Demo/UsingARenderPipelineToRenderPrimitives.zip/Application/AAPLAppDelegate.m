/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Implementation of our iOS & tvOS application delegate
*/

#import "AAPLAppDelegate.h"

@implementation AAPLAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    return YES;
}

@end
